#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include "fields.h"

int main(int argc, char **argv)
{
  IS is;
  int i;
  int fd_read ;
  int fd_write ;

  fd_read = open(argv[1], O_RDONLY);

  fd_write = open(argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0644);

  if (argc != 3) { fprintf(stderr, "input.txt"); exit(1); }
 
 

  is = new_inputstruct(argv[1]);
  if (is == NULL) {
    perror(argv[1]);
    exit(1);
  }

  int line;
  while(get_line(is) >= 0) {
    if(is->line < 4) continue;

    for (i = 0; i < is->NF; i++) {
      int freq;
      if(i % 2 == 0){
        sscanf(is->fields[i], "%d", &freq);
        // printf("%d\n", freq);
      }else{
        char* _char = is->fields[i];
        if(strcmp(_char, "s") == 0) _char = " ";
        for (int j = 0; j < freq; j++)
          write(fd_write, _char, strlen(_char));
      }

    }
      write(fd_write, "\n", 1);
  }

  
  jettison_inputstruct(is);
  return 0;
}